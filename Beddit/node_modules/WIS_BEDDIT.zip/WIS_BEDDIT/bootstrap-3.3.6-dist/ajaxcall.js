$(function () {

  
    var heartRate = function(){
        // alert('inside heartRate ajax'+dataJson);
        alert('inside bootstrap ajax');
        //var val1 = $('#firstname').val();
        //var val2 = $('#password').val();
        $.ajax({
            url: 'http://localhost:8080/dashboard',
            type: "GET",
            //data : {firstname: val1, password: val2},
           // crossDomain: true,
                success: function (resp) {
                    alert('successfully posted');
                    //   heartRate(resp);
                }

        })


      /*  $.ajax({
            url: 'http://localhost:8080/heartRate.js',
            type: "GET",
            data : {firstname: val1, password: val2},
            crossDomain: true,

        })*/

    }


    //sending email
    var sendmail = function () {
        console.log("send File");
        var val1 = $('#fromemail').val();
        var val2 = $('#toemail').val();
        var val3 = $('#subject').val();
        var val4 = $('#bodyarea').val();
        $.ajax({
            type: 'GET',
            url: 'http://localhost:8080/sendmail',
            // crossDomain: true,
            data:  {
                fromemail: val1, toemail: val2, subject:val3, bodyarea:val4,
            },

            success: function (resp) {
                alert('successfully posted' + resp);
                //  heartRate(resp);
            }

        });


    }

    // getting group info
var writegroup=function (resp) {
    console.log("inside write group function"+resp);
}
    var groupsinfo = function () {
        console.log("inside group info");

        $.ajax({
            type: 'GET',
            url: 'http://localhost:8080/groupinfo?firstname=mamidiravali1@gmail.com&password=ravaliraj',
            crossDomain: true,
            success: function (resp) {
                alert('successfully posted' + resp);
                writegroup(resp);
                //  heartRate(resp);
            }
        });
    }

    //to achieve acheivements

    var achieve = function () {
        console.log("inside achievements");

        $.ajax({
            type: 'GET',
            url: 'http://localhost:8080/achievements?firstname=mamidiravali1@gmail.com&password=ravaliraj',
            crossDomain: true,
            success: function (resp) {
                alert('successfully posted' + resp);
                //  heartRate(resp);
            }
        });
    }
    
    //$('#submit').click(getData);
    $('#submit').click(heartRate);
   // $('#invite').click(invite);
    $('#sendmail').click(sendmail);
   // $('#session').click(getSessionData);
    //$('#heartrate').click(heartRate);
    $('.groupsinfo').click(writegroup);
    $('#achieve').click(achieve);

});